import React, { useState } from "react";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css"; // Quill default theme
import { v4 as uuidv4 } from "uuid";

export default function ComposeMail() {
  const [to, setTo] = useState("");
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [loading, setLoading] = useState(false);

  const currentUser = localStorage.getItem("userEmail"); // store logged in email in localStorage after login
  const firebaseUrl = "https://mail-box-13540.firebaseio.com"; // 🔥 replace with your Firebase RTDB url

  const handleSend = async () => {
    if (!to || !subject || !body) {
      alert("All fields are required!");
      return;
    }

    setLoading(true);

    const mailId = uuidv4();
    const emailData = {
      id: mailId,
      from: currentUser,
      to,
      subject,
      body,
      timestamp: new Date().toISOString(),
      read: false,
    };

    try {
      // ✅ Save mail in receiver’s inbox
      await fetch(
        `${firebaseUrl}/mails/${to.replace(/\./g, "_")}/inbox/${mailId}.json`,
        {
          method: "POST",
          body: JSON.stringify(emailData),
        }
      );

      // ✅ Save mail in sender’s sentbox
      await fetch(
        `${firebaseUrl}/mails/${currentUser.replace(/\./g, "_")}/sent/${mailId}.json`,
        {
          method: "POST",
          body: JSON.stringify(emailData),
        }
      );

      alert("Mail sent successfully!");
      setTo("");
      setSubject("");
      setBody("");
    } catch (error) {
      console.error("Error sending mail:", error);
      alert("Failed to send mail!");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-400 to-purple-500 p-6">
      <div className="w-full max-w-3xl bg-white rounded-2xl shadow-lg p-8">
        <h2 className="text-3xl font-bold text-gray-800 mb-6">Compose Mail</h2>

        {/* To */}
        <input
          type="email"
          value={to}
          onChange={(e) => setTo(e.target.value)}
          placeholder="To"
          className="w-full mb-4 p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
        />

        {/* Subject */}
        <input
          type="text"
          value={subject}
          onChange={(e) => setSubject(e.target.value)}
          placeholder="Subject"
          className="w-full mb-4 p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
        />

        {/* Body */}
        <div className="mb-4">
          <ReactQuill
            value={body}
            onChange={setBody}
            theme="snow"
            className="bg-white rounded-lg"
            placeholder="Write your message..."
            style={{ height: "200px" }}
          />
        </div>

        {/* Send Button */}
        <button
          onClick={handleSend}
          disabled={loading}
          className="px-6 py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition"
        >
          {loading ? "Sending..." : "Send"}
        </button>
      </div>
    </div>
  );
}
