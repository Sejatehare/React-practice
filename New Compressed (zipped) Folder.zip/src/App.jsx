import './App.css'
import "react-draft-wysiwyg/dist/react-draft-wysiwyg.css";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Signup from "./components/Auth/Signup";
import Login from "./components/Auth/Login";
import Homepage from "./pages/homePage";
import ComposeMail from './components/folders/Composemail';
import ProfilePage from './pages/profilePage';

function App() {
  const token = localStorage.getItem("token");

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Navigate to="/login" />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/login" element={<Login />} />
        <Route
          path="/homepage"
          element={token ? <Homepage/> : <Navigate to="/login" />}
        />
        <Route path="/compose" element={token ? <ComposeMail /> : <Navigate to="/login" />} />
        <Route path="/profile" element={<ProfilePage/>} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
