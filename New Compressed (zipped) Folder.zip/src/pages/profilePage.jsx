import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { auth, database } from "../firebase/firebase";
import { ref, set, get } from "firebase/database";
import { onAuthStateChanged } from "firebase/auth";
import toast from "react-hot-toast";

export default function ProfilePage() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [name, setName] = useState("");
  const [mobile, setMobile] = useState("");
  const [photoURL, setPhotoURL] = useState("");
  const [editing, setEditing] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (!currentUser) {
        navigate("/login");
        return;
      }
      setUser(currentUser);
      // fetch existing profile
      const dbRef = ref(database, `users/${currentUser.uid}`);
      const snapshot = await get(dbRef);
      if (snapshot.exists()) {
        const data = snapshot.val();
        setName(data.name || "");
        setMobile(data.mobile || "");
        setPhotoURL(data.photoURL || "");
        setEditing(!data.name || !data.mobile || !data.photoURL);
      }
    });
    return () => unsubscribe();
  }, []);

  const handleSave = async () => {
    if (!name || !mobile || !photoURL) {
      toast.error("Please fill all fields!");
      return;
    }
    try {
      await set(ref(database, `users/${user.uid}`), {
        name,
        mobile,
        photoURL,
        email: user.email,
      });
      toast.success("Profile saved successfully!");
      setEditing(false);
    } catch (err) {
      toast.error("Failed to save profile.");
    }
  };

  const handleEdit = () => setEditing(true);

  const handleCancel = () => setEditing(false);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-r from-pink-300 to-blue-300 p-6">
      <div className="w-full max-w-lg bg-white rounded-3xl shadow-2xl p-10 flex flex-col gap-6">
        {editing ? (
          <>
            <h2 className="text-3xl font-bold text-gray-800 text-center">Complete Your Profile</h2>
            <input
              type="text"
              placeholder="Full Name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-pink-500"
            />
            <input
              type="text"
              placeholder="Mobile Number"
              value={mobile}
              onChange={(e) => setMobile(e.target.value)}
              className="px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-pink-500"
            />
            <input
              type="text"
              placeholder="Profile Photo URL"
              value={photoURL}
              onChange={(e) => setPhotoURL(e.target.value)}
              className="px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-pink-500"
            />
            <div className="flex justify-between mt-4">
              <button
                onClick={handleSave}
                className="px-6 py-3 bg-pink-500 text-white font-bold rounded-xl hover:bg-pink-600 transition"
              >
                Save
              </button>
              <button
                onClick={handleCancel}
                className="px-6 py-3 bg-gray-300 text-gray-700 font-bold rounded-xl hover:bg-gray-400 transition"
              >
                Cancel
              </button>
            </div>
          </>
        ) : (
          <div className="flex flex-col items-center gap-4">
            <img
              src={photoURL || "https://via.placeholder.com/100"}
              alt="Profile"
              className="w-24 h-24 rounded-full shadow-lg object-cover"
            />
            <h3 className="text-xl font-semibold">{name}</h3>
            <p className="text-gray-700">{user?.email}</p>
            <p className="text-gray-700">{mobile}</p>
            <button
              onClick={handleEdit}
              className="px-6 py-3 bg-pink-500 text-white font-bold rounded-xl hover:bg-pink-600 transition"
            >
              Edit
            </button>

            <button onClick={handleCancel} className="px-6 py-3 bg-pink-500 text-white font-bold rounded-xl hover:bg-pink-600 transition">
                Cancel
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
