export const firebaseConfig = {
  apiKey: "AIzaSyAl2_-4qrH9gTXCHoxpWVKvUtpgfgrcVTo",
  authDomain: "expense-tracker-3817d.firebaseapp.com",
  databaseURL: "https://expense-tracker-3817d-default-rtdb.firebaseio.com",
  projectId: "expense-tracker-3817d",
  storageBucket: "expense-tracker-3817d.firebasestorage.app",
  messagingSenderId: "367512992721",
  appId: "1:367512992721:web:c7f3a9fd02bb66c0c3fef0",
};
