import { useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import { auth, database } from "../firebase/firebase";
import { ref, get } from "firebase/database";
import { onAuthStateChanged } from "firebase/auth";
import ProfilePage from "../pages/profilePage";

export default function HomePage() {
  const navigate = useNavigate();
  const [active, setActive] = useState("Inbox"); // default active
  const [profilePhoto, setProfilePhoto] = useState(null);
  const [showProfile, setShowProfile] = useState(false);

  const menuItems = ["Compose", "Inbox", "Sent", "Bin", "Starred"];

  // Fetch user profile
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (!currentUser) {
        navigate("/login");
        return;
      }
      const dbRef = ref(database, `users/${currentUser.uid}`);
      const snapshot = await get(dbRef);
      if (snapshot.exists()) {
        const data = snapshot.val();
        setProfilePhoto(data.photoURL);
      }
    });
    return () => unsubscribe();
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/login");
  };

  return (
    <div className="flex min-h-screen w-screen bg-gradient-to-br from-pink-300 to-blue-300 text-gray-900">
      {/* Sidebar */}
      <aside className="w-64 bg-gradient-to-l from-pink-50 to-blue-50 shadow-xl flex flex-col">
        <h2 className="text-2xl font-bold p-6 text-gray-800">📨 Mailbox</h2>
        <nav className="flex flex-col gap-2 px-4 mt-2 flex-1">
          {menuItems.map((item) => (
            <button
              key={item}
              onClick={() => setActive(item)}
              className={`text-left px-5 py-3 rounded-lg font-medium transition
                ${
                  active === item
                    ? "bg-gradient-to-r from-purple-400 to-blue-400 text-white shadow-md scale-[1.02]"
                    : "text-gray-800 hover:bg-purple-300/50"
                }`}
            >
              {item === "Compose" && "✉️ "}
              {item === "Inbox" && "📥 "}
              {item === "Sent" && "📤 "}
              {item === "Bin" && "🗑️ "}
              {item === "Starred" && "⭐ "}
              {item}
            </button>
          ))}
        </nav>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <header className="flex justify-between items-center px-8 py-4 bg-gradient-to-r from-pink-50 to-blue-50 shadow-sm">
          <h1 className="text-3xl font-bold text-gray-800">{active}</h1>
          <div className="flex items-center gap-4">
            {/* Profile Photo */}
            <img
              src={profilePhoto || "https://via.placeholder.com/40"}
              alt="Profile"
              className="w-10 h-10 rounded-full cursor-pointer border-2 border-white shadow-md hover:scale-110 transition"
              onClick={() => setShowProfile(true)}
            />
            <button
              onClick={handleLogout}
              className="px-5 py-2 bg-gradient-to-r from-pink-500 to-red-500 text-white font-semibold rounded-full shadow-md hover:scale-105 transition"
            >
              Logout
            </button>
          </div>
        </header>

        {/* Content Area */}
        <main className="flex-1 p-8 overflow-y-auto">
          <div className="rounded-2xl shadow-md p-10 h-full flex items-center justify-center text-xl font-medium text-gray-700 bg-gradient-to-r from-pink-50 to-blue-50">
            ✨ {active} messages will appear here ✨
          </div>
        </main>
      </div>

      {/* Profile Modal */}
      {showProfile && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-3xl shadow-2xl w-11/12 max-w-md p-6 relative">
            <button
              className="absolute top-4 right-4 text-gray-500 font-bold text-xl"
              onClick={() => setShowProfile(false)}
            >
              &times;
            </button>
            <ProfilePage />
          </div>
        </div>
      )}
    </div>
  );
}
