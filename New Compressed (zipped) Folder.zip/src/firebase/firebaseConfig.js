export const firebaseConfig = {
  apiKey: "AIzaSyCS78u_o-JeNbkUlxgnGzjAAE1fREGlC3c",
  authDomain: "mail-box-13540.firebaseapp.com",
  projectId: "mail-box-13540",
  storageBucket: "mail-box-13540.firebasestorage.app",
  messagingSenderId: "560186105747",
  appId: "1:560186105747:web:5c22daa9b05f2a9ccc1266",
  measurementId: "G-3PZB86HBEL"
};